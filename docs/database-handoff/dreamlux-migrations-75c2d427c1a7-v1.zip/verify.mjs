import { createHash } from "node:crypto";
import { lstatSync, readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(readFileSync(join(root, "manifest.json"), "utf8"));
if (manifest.formatVersion !== 1 || manifest.repository !== "LeulTew/dreamlux-erp" ||
    !/^[a-f0-9]{40}$/.test(manifest.sourceCommit) || !Array.isArray(manifest.files)) {
  throw new Error("Unexpected DreamLux handoff manifest.");
}
const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");
const expected = new Set(["manifest.json"]);
for (const file of manifest.files) {
  const parts = file.path.split(/[\\/]/);
  if (parts.some((part) => !part || part === "." || part === ".." || part.includes(":")) ||
      expected.has(file.path) || /(^|\/)(?:\.env[^/]*|node_modules|\.auth|\.next)(\/|$)/.test(file.path)) {
    throw new Error(`Unsafe or duplicate archive entry: ${file.path}`);
  }
  expected.add(file.path);
  const path = join(root, ...parts);
  const stat = lstatSync(path);
  if (!stat.isFile() || stat.isSymbolicLink()) throw new Error(`Not a regular file: ${file.path}`);
  const bytes = readFileSync(path);
  if (bytes.length !== file.bytes || sha256(bytes) !== file.sha256 ||
      sha256(Buffer.from(bytes.toString("utf8").replace(/\r\n/g, "\n"))) !== file.lfSha256) {
    throw new Error(`Checksum mismatch: ${file.path}`);
  }
}
function walk(path, prefix = "") {
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isSymbolicLink()) throw new Error(`Unexpected symlink: ${relative}`);
    if (entry.isDirectory()) walk(join(path, entry.name), relative);
    else if (!expected.has(relative)) throw new Error(`Unlisted file: ${relative}`);
  }
}
walk(root);
console.log(JSON.stringify({
  result: "offline-checksums-verified",
  sourceCommit: manifest.sourceCommit,
  files: manifest.files.length + 1,
  schemaReplayTested: false,
  remoteAppliedStatus: manifest.remoteAppliedStatus,
}));
