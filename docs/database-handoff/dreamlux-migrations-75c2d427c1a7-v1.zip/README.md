# DreamLux migration-source handoff

This is an offline source archive, not a database backup or a runnable migration
chain. No database was contacted to create or verify it. Verify the separately
published ZIP and manifest SHA-256 values, extract into a new directory, then run
`bun --no-env-file verify.mjs` there. The verifier reads files only: it does not
load environment files, import application helpers, install packages or connect
to a service.

## Existing owner transfer versus a new database

An existing Supabase project can be transferred between organizations using the
owner-authorized project-transfer workflow. Do not replay schema SQL merely
because the owner/organization changes. Review the current prerequisites,
permissions, integrations, plan and billing implications with the owners:
https://supabase.com/docs/guides/platform/project-transfer

A new project or a region move is different. It requires a separately approved
target, compatibility/replay design, secrets/configuration provisioning, data and
Auth migration, Storage-object migration, integrations, backup/recovery plan and
cutover. This archive performs none of those actions and contains no account,
data, Storage, credential or full-application backup.

## Contents and provenance

`manifest.json` pins the repository commit, Git blob IDs, raw source SHA-256,
LF-normalized source SHA-256, included-file checksums, classifications,
prerequisite notes and the original package-script ordering. The manifest's
array order is an inventory order, NOT a safe execution order.

Every tracked SQL file is accounted for. Baseline and 36 of the 37 incremental
SQL files are preserved byte-for-byte from Git. One mixed permission migration
has an explicitly marked sanitized extract: only its original lines 1-13 are
included. Its user/password bootstrap block and comments are deliberately NOT
distributed. Original path, commit, blob and checksums remain in the manifest;
the extract is not falsely labeled as the original file.

Standalone employee/user seed SQL and personnel/data-copy scripts are excluded.
Definitions such as `CREATE TABLE users (... password_hash TEXT ...)` are schema,
not exported accounts. Existing role/permission catalogs, default store/salary/
event-type settings and data-normalization SQL remain inside historical
baseline/migration files. Therefore this is NOT a "DDL-only" or "zero-DML"
archive. Those embedded policy/default writes require review; do not run them
against an owner's existing records/grants.

Five original TypeScript helpers preserve inline legacy DDL that was not fully
represented by SQL files. They are reference material, NOT entrypoints:
some connect or execute on import, read `.env`, use an RPC, swallow failures,
or seed/update settings. No environment files, database URLs, dependencies or
connection credentials are included. A separately labeled SQL extract preserves
the inventory audit/history prerequisite statements embedded in `assets.ts`,
with source hash and exact line ranges; the controller itself is not copied.

`verify-inventory-workflow.sql` is a historical read-only diagnostic helper, not
a migration. It includes psql meta-commands and is not directly pasteable into
the Supabase SQL Editor.

## Ordering and compatibility warnings

- The baseline overlaps many increments and contains data/catalog writes,
  store deduplication and immutable-history triggers. `IF NOT EXISTS` is not a
  complete reconciliation of existing columns, types, constraints or policies.
- The package-declared legacy runner order is preserved as evidence, not
  endorsed as complete. Several files have no entry in that chain; it does not
  create a checksummed migration ledger.
- Both dated fuel migrations target the same named constraint. Review them as
  overlapping alternatives, not two independent missing changes.
- `event_level_pricing.sql` creates/backfills legacy event-type pricing;
  `decentralized_event_pricing.sql` later drops those pricing columns and moves
  employee salary references. Never concatenate or rerun them blindly.
- The July dispatch permission files represent policy evolution. The sanitized
  older grant does not override the later split. Preserve current grants.
- Compensation and attendance migrations contain explicit historical-record
  rules. Do not replace them with blanket salary/attendance rewrites.
- Reconciliation hardening and the extracted audit/history prerequisites
  overlap, including timestamp/type and partial-schema differences. Compare
  the destination catalog before selecting statements.
- Baseline table creation is not the same as complete Supabase provisioning.
  Reassess RLS, grants, functions/triggers, extensions, publication membership
  and Storage policies against the real approved target. Do not copy another
  product's roles or configuration to fill gaps.

No clean-database replay, production ledger parity, restore drill, data export
or ownership transfer is certified by this archive. All remote applied states
are explicitly unknown in `remote-applied-status.json` until an authorized
DreamLux database catalog/history inspection supplies independent evidence.
