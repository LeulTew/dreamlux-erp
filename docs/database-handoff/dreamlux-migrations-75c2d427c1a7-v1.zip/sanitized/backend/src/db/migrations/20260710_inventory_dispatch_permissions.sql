-- Issue #129: allow storekeeper inventory roles to operate dispatch checklist/departure flows.

INSERT INTO permissions (slug, description) VALUES
  ('event_allocations:write', 'Create and release event inventory allocations')
ON CONFLICT (slug) DO UPDATE SET
  description = EXCLUDED.description;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
JOIN permissions p ON p.slug = 'event_allocations:write'
WHERE LOWER(r.name) IN ('inventory_officer', 'inventory_controller')
ON CONFLICT DO NOTHING;
